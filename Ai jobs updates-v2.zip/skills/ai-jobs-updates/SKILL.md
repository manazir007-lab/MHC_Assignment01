---
name: "ai-jobs-updates"
description: Finds the latest AI job openings (machine learning, data science, LLM, generative AI, AI research, MLOps, prompt engineering, AI product and policy roles) and gives full organization details plus verified ways to contact or apply. Use this skill whenever the user asks about AI jobs, ML or data science vacancies, AI hiring news, AI internships, fresher or experienced AI roles, who is hiring in AI, or wants an update on the AI job market, even if they don't say "skill" or give a specific company. Also use it when the user asks how to contact or apply to an organization for an AI role.
---

# AI Jobs Updates

Give the user a current, trustworthy briefing on AI job openings, with enough detail about each organization that they can decide whether to apply and know exactly how to do it.

Job postings change daily and close without notice. Anything remembered from training is stale, so every run of this skill must be built on fresh web searches. Never list jobs from memory.

## Step 1: Pin down the search (ask only what is missing)

Infer as much as possible from the request and conversation. If something important is missing, ask one short question, or state an assumption and proceed. The useful inputs are:

- **Role type**: ML engineer, data scientist, research scientist, GenAI/LLM engineer, MLOps, AI product manager, AI policy, etc.
- **Experience level**: intern, fresher, mid, senior
- **Location**: country or city, remote, or hybrid. Use the user's stated location. If none is given, default to a mix of remote roles and roles in the user's country, and say so.
- **Employer type**: startups, big tech, government, research labs, academia (optional)

If the request is broad ("latest AI jobs"), do not stall on questions. Give a balanced overview across a few role types and offer to narrow it down.

## Step 2: Search

Run several separate searches rather than one combined query, since combined queries return shallow results. Keep queries short and specific, and include the current year or month for recency. Examples:

- `AI engineer jobs hiring [month year]`
- `machine learning careers [location]`
- `generative AI hiring news`
- `[company name] careers AI`

Prefer, in this order:

1. **The employer's own careers page** (the most reliable and most current)
2. **Established job boards** (LinkedIn, Indeed, Naukri, Glassdoor, Wellfound, company ATS pages such as Greenhouse, Lever, Workday)
3. **Government portals** for public sector AI roles
4. **News and industry coverage** for hiring trends and which companies are expanding

Use `web_fetch` on promising job or careers pages to confirm details instead of relying on search snippets. Open the actual posting to check that it is still live, the date posted, and the application method.

Aim for roughly 5 to 10 distinct, verified openings, and fewer if the search genuinely turns up fewer. Quality matters more than count.

## Step 3: Verify before including

Skip or flag any opening that fails these checks:

- The posting is on the employer's official site or a reputable board that links to it.
- It appears current. Note the posted date, and the deadline if there is one. If you cannot confirm it is open, say "could not confirm if still open".
- The employer is real and identifiable. Be wary of postings with no company name, vague duties, promises of very high pay for little skill, or requests for payment.

Recruitment scams are common in the AI job space. Real employers do not charge application, training, or "security deposit" fees.

## Step 4: Present the results

Start with a two- to three-sentence snapshot of what the market looks like right now (which roles and employers are hiring most), based only on what the searches found. Then list the openings using this structure for each one:

```
### [Job title], [Organization]
- **Location / work mode:** 
- **Level and type:** (intern / full-time / contract)
- **Posted / deadline:** 
- **What the role involves:** 1 to 2 sentences, in your own words
- **Key requirements:** skills, degrees, experience
- **Pay:** only if listed; otherwise "not disclosed"

**About the organization**
- **What they do:** 1 to 2 sentences
- **Type and size:** startup, public company, government, lab; approximate headcount if known
- **Headquarters / main offices:** 
- **Website:** 

**How to apply or contact**
- **Apply here:** direct link to the posting
- **Careers page:** link
- **Official contact:** see rules below
```

After the list, add a short **Next steps** section: a tip or two for the user's situation (for example, tailoring a CV to the posting's keywords), and an offer to narrow by role, location, or experience level.

## Rules for contact details

The user wants to know how to reach the organization, which is reasonable, but contact details are where fabrication does the most harm.

- Only give contact information you actually found on the organization's official website or the posting itself: careers page, a published recruiting email, official LinkedIn company page, or a published HR or general phone number.
- Never guess or construct an email address (for example, inventing `careers@company.com`) or a phone number. If you did not see it on an official page, do not include it.
- When no direct contact was found, say so plainly and give the best verified route instead, such as the official application portal, the company's "Contact us" page, or its official LinkedIn page.
- Do not share personal contact details of individual employees or recruiters unless they are published in the posting itself as the designated contact.
- Remind the user to apply only through official channels and to treat unsolicited messages offering jobs with caution.

## Quality notes

- Paraphrase job descriptions. Do not copy posting text at length.
- Cite where each listing came from so the user can check it.
- State the date of the search, since listings go stale quickly.
- Be honest about gaps. If the search for a given location or level found little, say that instead of padding the list with weak or unverified results.
- If the user wants salary guidance, interview prep, or CV help after seeing the jobs, help directly. This skill's focus is finding and presenting current openings.
